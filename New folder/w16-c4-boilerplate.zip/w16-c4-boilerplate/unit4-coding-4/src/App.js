import logo from "./logo.svg";
import "./App.css";
import { MainRoutes } from "./Routes/MainRoutes";

function App() {
  return (
    <>
     <MainRoutes/> 
    </>
  );
}

export default App;
