import React from 'react'

function Home() {
  return (
    <div className='w-fit m-auto font-bold text-2xl mt-4'>
        Home
    </div>
  )
}

export default Home