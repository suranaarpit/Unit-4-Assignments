import React from "react";

function PageNotFound() {
  return (
    <>
      <img src="https://raw.githubusercontent.com/suranaarpit/React-Router-Project/main/src/Images/Error.gif" alt="404-Error"/>
    </>
  );
}

export default PageNotFound;