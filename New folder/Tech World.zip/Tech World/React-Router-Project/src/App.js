import TechWorld from "./Components/TechWorld";


function App() {
  return (
    <div>
    <TechWorld/>
    </div>
  );
}

export default App;
