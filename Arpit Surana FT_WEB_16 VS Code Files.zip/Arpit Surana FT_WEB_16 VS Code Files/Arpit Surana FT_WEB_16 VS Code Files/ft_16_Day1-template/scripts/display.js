//here retrieve the generated number from Localstorage.


let number = localStorage.getItem("number");
let color;
if(number == "1"){
    color = "yellow";
}
else if(number == "6"){
    color = "green";
}
else{
    color = "red";
}
let div = document.querySelector("#show_number");
div.innerText = number;
div.style.color = color;