//Store the generated number in LocalStorage with key "number".

let min = 1;
let max = 7;
let button = document.getElementById("throw_dice");
button.addEventListener("click", function(){
    number();
})
function number(){
    let random = Math.floor(Math.random()*(max-min)+min);
    localStorage.setItem("number", random);
    window.location.href = "./display.html"
}
