var cartarray= JSON.parse(localStorage.getItem("cartArray"))||[];
var user_name = localStorage.getItem("loggedUser") || "Guest";
var user= document.querySelector(".userName");
user.innerText=user_name;
var promoCode = document.querySelector(".promo>input[type='button']");
var checkout = document.querySelector(".checkout");

promoCode.addEventListener("click",apply_discount);
checkout.addEventListener("click",success);



if(cartarray.length!=0){
  document.querySelector(".promo").style.display="flex";
  checkout.style.display="block";
}
function display_data(cartarray) {
    document.querySelector("#container").innerHTML="";
    cartarray.map(function (elem,index) {
        var mainDiv = document.createElement("div");
    
        var img = document.createElement("img");
        img.setAttribute("src", elem.image_url);
    
        var name = document.createElement("p");
        name.innerText = elem.name;
    
        var price_div = document.createElement("div");
    
        var price = document.createElement("h2");
        price.innerText = "$"+elem.price;
    
        var strikedoffprice = document.createElement("p");
        strikedoffprice.innerText = "$"+elem.strikedoffprice;
    
        var inc_qty = document.createElement("button");
        inc_qty.innerText = "+";
        inc_qty.className="inc";
        inc_qty.addEventListener("click", function () {
          increase_qty(index);
        });
    
        var quantity = document.createElement("p");
        quantity.innerText =elem.qty;
        var dec_qty = document.createElement("button");
        dec_qty.innerText = "-";
        dec_qty.className="dec";
        dec_qty.addEventListener("click", function () {
          decrease_qty(index);
        });
    
    
        price_div.append(price, strikedoffprice,dec_qty,quantity,inc_qty);
        mainDiv.append(img, name, price_div);
    
        document.querySelector("#container").append(mainDiv);
      }); 
}



function apply_discount(){
  var code = document.querySelector("#promo").value;
  var total = cartarray.reduce(function(acc,elem){
    return acc+(elem.price * elem.qty);
  },0);
  if(code=='masai30'){
    document.querySelector(".total-price").innerText= "$"+Math.floor((total/100)*70);
    document.querySelector(".code_or_not").innerText="Code Applied";
    document.querySelector(".code_or_not").style.padding="4px 8px";

  }else if(code.trim().length==0){
    alert("Please enter some code first");
  }
  
  else {
    alert("wrong code");
  }
  document.querySelector("#promo").value="";
}
 

function success(){
  window.location.href="success.html";
}




 function show_total(){
    var total = cartarray.reduce(function(acc,elem){
        return acc+(elem.price * elem.qty);
    },0);
  
    var total_price = document.querySelector(".total-price");
  
    total_price.innerText="$"+total;
 }

 display_data(cartarray);
 show_total();

var total_items= document.querySelector(".total-items");
total_items.innerText= cartarray.length;



  function increase_qty(index) {
      cartarray[index].qty++;
      localStorage.setItem("cartArray",JSON.stringify(cartarray));
      display_data(cartarray);
      show_total();
  }

  function decrease_qty(index) {
      if(cartarray[index].qty>1){
          cartarray[index].qty--;
      }
      localStorage.setItem("cartArray",JSON.stringify(cartarray));
      display_data(cartarray);
      show_total();
  }