womensData.map(function (elem) {
    var mainDiv = document.createElement("div");

    var img = document.createElement("img");
    img.setAttribute("src", elem.image_url);

    var name = document.createElement("p");
    name.innerText = elem.name;

    var price_div = document.createElement("div");

    var price = document.createElement("h2");
    price.innerText = "$"+elem.price;

    var strikedoffprice = document.createElement("p");
    strikedoffprice.innerText = elem.strikedoffprice;
    var cart = document.createElement("button");
    cart.innerText = "Add to cart";
    cart.className="btn2";
    cart.addEventListener("click", function () {
      addToCart(elem);
    });
    price_div.append(price, strikedoffprice,cart);
    mainDiv.append(img, name, price_div);

    document.querySelector("#container").append(mainDiv);
  });


  var user_name = localStorage.getItem("loggedUser") || "Guest";
  var user= document.querySelector(".userName");
  user.innerText=user_name;
 

  var cartarray= JSON.parse(localStorage.getItem("cartArray"))||[];
  function addToCart(elem) {
    elem.qty=1;
    cartarray.push(elem);
    localStorage.setItem("cartArray",JSON.stringify(cartarray));
  }