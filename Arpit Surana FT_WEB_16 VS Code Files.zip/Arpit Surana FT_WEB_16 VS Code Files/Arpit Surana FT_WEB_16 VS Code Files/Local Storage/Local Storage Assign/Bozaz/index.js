document.querySelector("#form").addEventListener("submit", formSubmit);
var data  = JSON.parse(localStorage.getItem("Bozaz")) || [];
var count= data.length+1;
function formSubmit(event){
    event.preventDefault();
    var category = document.querySelector("#category").value;
    var title = document.querySelector("#title").value;
    var textArea = document.querySelector("#textarea").value;
    var price = document.querySelector("#price").value;

    var addObj = {
        count:count++,
        category: category,
        title: title,
        textArea: textArea,
        price: price
    };
    data.push(addObj);
    console.log(data)
    Add_data(addObj);
    localStorage.setItem("Bozaz", JSON.stringify(data));
}


var data = JSON.parse(localStorage.getItem("Bozaz"))||[];
// var added = JSON.parse(localStorage.getItem("addedData")) || [];
console.log(data);

    document.querySelector("#body").innerHTML = null;
    data.map(function(element, index){
       Add_data(element)
    });

    function Add_data(element){
        var row = document.createElement("tr");
        var col1 = document.createElement("td");
        col1.innerText = element.count;
        var col2 = document.createElement("td");
        col2.innerText = element.category;
        var col3 = document.createElement("td");
        col3.innerText = element.title;
        var col4 = document.createElement("td");
        col4.innerText = element.textArea;
        var col5 = document.createElement("td");
        col5.innerText = element.price;
        row.append(col1, col2, col3, col4, col5);
        document.querySelector("#body").append(row);
    }