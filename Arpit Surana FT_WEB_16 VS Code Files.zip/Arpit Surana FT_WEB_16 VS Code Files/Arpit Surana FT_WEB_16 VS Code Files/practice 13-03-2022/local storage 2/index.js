document.querySelector("form").addEventListener("submit", formSubmit);

let newArr = JSON.parse(localStorage.getItem("todoList")) || [];

function formSubmit(event){
    event.preventDefault();
    let todo = form.name.value;
    let qty = form.qty.value;
    let pri = form.priority.value;

    let todoObj = {
        todoName: todo,
        todoQty: qty,
        todoPri: pri,
    };

    newArr.push(todoObj);
    console.log(newArr);
    localStorage.setItem("todoList", JSON.stringify(newArr));
}