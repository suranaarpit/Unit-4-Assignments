let imagesData = [

    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/4378/1124378-v-fd102213bb26",name: "Turning Red"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/2181/1122181-v-0fa7b5e161de",name: "Rudra"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/4622/1114622-v-6aa53dbe426f",name: "A Thursday"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/4378/1124378-v-fd102213bb26",name: "Turning Red"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/2181/1122181-v-0fa7b5e161de",name: "Rudra"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/4622/1114622-v-6aa53dbe426f",name: "A Thursday"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/4378/1124378-v-fd102213bb26",name: "Turning Red"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/2181/1122181-v-0fa7b5e161de",name: "Rudra"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/4622/1114622-v-6aa53dbe426f",name: "A Thursday"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/4378/1124378-v-fd102213bb26",name: "Turning Red"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/2181/1122181-v-0fa7b5e161de",name: "Rudra"},
    {poster: "https://img1.hotstarext.com/image/upload/f_auto,t_web_vl_3x/sources/r1/cms/prod/4622/1114622-v-6aa53dbe426f",name: "A Thursday"}
    
];

