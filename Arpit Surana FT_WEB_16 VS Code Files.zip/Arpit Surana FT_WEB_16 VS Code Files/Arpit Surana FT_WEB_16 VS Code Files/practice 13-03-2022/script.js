let maindiv = document.getElementById("main")


imagesData.map(function(el){
    let div1 = document.createElement("div");
    div1.setAttribute("id", "div1");

    let pos = document.createElement("img");
    pos.setAttribute("class", "poster")
    pos.setAttribute("src", el.poster);

    let name = document.createElement("p");
    name.setAttribute("class", "head")
    name.innerText = el.name;

    div1.append(pos, name);
    maindiv.append(div1);
})