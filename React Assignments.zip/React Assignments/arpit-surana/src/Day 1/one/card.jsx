const Card = () => {
  return (
    <>
      <div id="card">
        <h1>Mobile Operating System</h1>
        <ul>
          <li>Android</li>
          <li>BlackBerry</li>
          <li>iphone</li>
          <li>Windows Phone</li>
        </ul>

        <h1>Mobile Manufraturers</h1>
        <ul>
          <li>Samsung</li>
          <li>HTC</li>
          <li>Micromax</li>
          <li>Apple</li>
        </ul>
      </div>
    </>
  );
};
export default Card;
