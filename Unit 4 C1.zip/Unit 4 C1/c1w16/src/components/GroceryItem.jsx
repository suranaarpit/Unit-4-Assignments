// reusable card component
import CartButton from "./CartButton";
const GroceryItem = ({title, imgURL, mrp, sellingPrice, discount}) => {
  return <>
<div id="grocItem">
  <div className="border">
    <p className="discount">{discount}</p>
    <img src={imgURL} alt="image" />
    <h2>{title}</h2>
    <h4>{sellingPrice}</h4>
    <p>MRP: {mrp}</p>
  </div>
  <CartButton/>
</div>
  </>;
};
export default GroceryItem;
