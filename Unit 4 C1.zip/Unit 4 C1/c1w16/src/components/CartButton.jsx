
// keep the add to cart component here
import { useState } from "react"; 
const CartButton = () => {
    //manage state of the count 
    const [count, setCount] = useState(0);
  return (
  
  <>
  
  <div id = "btn">
    {count>0 ?(
      <>
            <button className = "min" onClick = {()=>setCount((countMin)=>countMin-1)}>-</button>
      <p className="count-item">{count}</p>
      <button className = "add" onClick = {()=>setCount((countAdd)=>countAdd+1)}>+</button>
      </>
    ): (
      <p onClick={()=>setCount((countMin)=>countMin + 1)} className = "addToCart">Add To Cart</p>
    )}

  </div>
  </>  
);

};
export default CartButton
