import logo from './logo.svg';
import './App.css';
import GroceryDetails from './components/Grocerydetails';
import GroceryItem from './components/GroceryItem';

function App() {
  return (
    <div className="App">
     <GroceryDetails/>
     <GroceryItem/>
    </div>
  );
}

export default App;
